

<?php $__env->startSection('content'); ?>


    <main>
   

        <!-- Main page content-->
        <div class="container mt-n5">


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
                    <div class="card">
                    <div class="card-header">Subscribe a user</div>
                    <div class="card-body">


                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session('subscribtionError')): ?>

                    <div class="alert alert-danger m-3" role="alert"><?php echo e(session('subscribtionError')); ?></div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('subscriptions.userSubscription')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>

                        <div class="row gx-3 mb-3">


                        <div class="col-md-6">
                            <label class="small mb-1" for="name">User</label>
                            <select name="user_id" id="user_id" class="form-control form-control-solid" required>
                                        <option value="" >Select a user </option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                        </div>

                        <div class="col-md-6">
                            <label class="small mb-1" for="package_id">Package</label>
                            <select name="package_id" id="package_id" class="form-control form-control-solid" required>
                                        <option value="" >Select a package </option>
                                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($package->id); ?>"><?php echo e($package->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                        </div></div>
                   
                        <div class="row gx-3 mb-3">
                             <div class="col-md-6">
                               <label class="small mb-1" for="period_in_months">Period in months </label>
                               <input type="number" name="period_in_months" id="period_in_months" class="form-control" value="<?php echo e(old('period_in_months')); ?>" required/>
                
                             </div>

                       
                        <div class="col-md-6" style="margin-top: 35px;">
                        <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                    </div></div>
                    </form>

            </div>
        </div>
        </div>
    </main>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/subscribtions/showSubscribeUser.blade.php ENDPATH**/ ?>