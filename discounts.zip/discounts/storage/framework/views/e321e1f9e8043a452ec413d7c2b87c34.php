

<?php $__env->startSection('content'); ?>


    <main>


        <!-- Main page content-->
        <div class="container mt-n5">

        <?php if(session('success')): ?>

       <div class="alert alert-success m-3" role="alert"><?php echo e(session('success')); ?></div>
       <?php endif; ?>


            


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

                    <div class="row gx-4">
                    <div class="col-12">
                    <div class="card mb-4">
                    <div class="card-header">
                    <?php echo e($ticket->title); ?>

                    By User <?php echo e($ticket->user->first_name); ?> <?php echo e($ticket->user->last_name); ?>

                    </div>

                    <div class="card-body">
                        <input class="form-control"  type="text" value="<?php echo e($ticket->body); ?>" readonly />
                       
                    </div>
                    </div>
                    

                   

                                    <div class="card card-header-actions mb-4">
                                    <div class="card-header">
                                        Replies
                                    <i class="text-muted" data-feather="info" data-bs-toggle="tooltip" data-bs-placement="left" title="The post preview text shows below the post title, and is the post summary on blog pages."></i>
                                    </div>
                                    <div class="card-body">
                                        <ul>
                                            <?php $__currentLoopData = $relatedTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedTicket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <?php echo e($relatedTicket->body); ?>

                                                
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>

                    <h4>Reply to this Ticket</h4>
                    <form method="POST" action="<?php echo e(route('tickets.storeReply', $ticket->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div>
                            
                            
                        <textarea class="form-control" name="reply_body" id="reply_body"required></textarea>
                        <?php $__errorArgs = ['reply_body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                        <div>
                            <br>
                            <button type="submit">Submit Reply</button>
                        </div>
                    </form>


                </div>
            </div>
    </main>

 


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/tickets/show.blade.php ENDPATH**/ ?>