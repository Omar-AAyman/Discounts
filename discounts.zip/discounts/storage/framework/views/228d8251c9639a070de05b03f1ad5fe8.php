
<?php $__env->startSection('content'); ?>

<main>
    <!-- Main page content -->
    <div class="container mt-n5">

        <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

        <div class="card">
            <div class="card-header">Discount change pending requests</div>
            <div class="card-body">

                <?php if($changeRequests->isEmpty()): ?>
                    <p>No Requests.</p>
                <?php else: ?>
                    <div class="mt-3 table-container">
                    <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <?php if(session('fail')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('fail')); ?>

                </div>
            <?php endif; ?>

                        <table id="myTable" class="table small-table-text">
                            <thead>
                                <tr style="white-space: nowrap; font-size: 14px;">
                                   
                                    <th>offer belongs to store</th>
                                    <th>Old discount (%)</th>
                                    <th>New requested discount % </th>
                                  
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $changeRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $changeRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr style="white-space: nowrap; font-size: 14px;">
                                        <td><?php echo e($changeRequest->offer->store->name); ?></td>
                                        <td><?php echo e($changeRequest->offer->discount_percentage); ?></td>
                                        <td><?php echo e($changeRequest->new_discount_percentage); ?></td>
                                        
                                       
                                        <td>
                                            <form method="post" action="<?php echo e(route('offerNotifications.accept', $changeRequest->id)); ?>">
                                                <?php echo csrf_field(); ?> 
                                                <button type="submit" class="btn btn-success btn-xs">Accept</button>
 
                                            </form>

                                        </td>
                                                       
                                        <td>
                                            <form method="post" action="<?php echo e(route('offerNotifications.reject', $changeRequest->id)); ?>">
                                                <?php echo csrf_field(); ?> 
                                                <button type="submit" class="btn btn-danger btn-xs">Reject</button>
 
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>

<script>
    let table = new DataTable('#myTable', {
        ordering: false // Disable DataTables' default ordering
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/offerNotifications/pending.blade.php ENDPATH**/ ?>