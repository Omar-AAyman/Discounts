

<?php $__env->startSection('content'); ?>


    <main>
   

        <!-- Main page content-->
        <div class="container mt-n5">


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
                    <div class="card">
                    <div class="card-header">Subscribe a guest</div>
                    <div class="card-body">


                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <?php if(session('subscribtionError')): ?>

                    <div class="alert alert-danger m-3" role="alert"><?php echo e(session('subscribtionError')); ?></div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('subscriptions.guestSubscription')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>

                        <div class="row gx-3 mb-3">


                        <div class="col-md-6">
                            <label class="small mb-1" for="name">User</label>
                            <select name="user_id" id="user_id" class="form-control form-control-solid" required>
                                        <option value="" >Select a user </option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                        </div>
                   
                    
                       
                        <div class="col-md-6" style="margin-top: 35px;">
                        <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                    </div></div>
                    </form>

            </div>
        </div>
        </div>
    </main>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/subscribtions/showSubscribeGuest.blade.php ENDPATH**/ ?>