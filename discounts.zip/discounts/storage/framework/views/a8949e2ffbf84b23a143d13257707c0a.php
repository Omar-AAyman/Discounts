

<?php $__env->startSection('content'); ?>


    <main>


        <!-- Main page content-->
        <div class="container mt-n5">


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

                    <div class="card">
                    <div class="card-header">Add Seller 
                   
                    </div>
                        <?php if(session('success')): ?>

                        <div class="alert alert-success m-3" role="alert"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if($errors->has('fail')): ?>
                            <div class="alert alert-danger m-3">
                                <?php echo e($errors->first('fail')); ?>

                            </div>
                        <?php endif; ?>


                        
                        <div class="card-body">
                         
                           <a href="<?php echo e(route('delegates.createSeller')); ?>" class="btn btn-success btn-sm">Add Seller</a>
                         </div>     
                        

                       
                    </div>
                </div>

        
    </main>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout-delegate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/delegate.blade.php ENDPATH**/ ?>