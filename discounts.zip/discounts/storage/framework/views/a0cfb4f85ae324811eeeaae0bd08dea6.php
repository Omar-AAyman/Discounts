

<?php $__env->startSection('content'); ?>


    <main>


        <!-- Main page content-->
        <div class="container mt-n5">


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

                    <div class="card">
                    <div class="card-header">Guests Subscribtion List For <?php echo e(isset($packageName)? $packageName->value : 'Basic'); ?> Package
                   
                    </div>
                        <?php if(session('success')): ?>

                        <div class="alert alert-success m-3" role="alert"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if($errors->has('fail')): ?>
                            <div class="alert alert-danger m-3">
                                <?php echo e($errors->first('fail')); ?>

                            </div>
                        <?php endif; ?>


                        <?php if($subscribtions->isEmpty()): ?>
                        <div class="card-body">
                            <a class="btn btn-success btn-sm mb-3" href="<?php echo e(route('subscriptions.showSubscribeGuest')); ?>">subscribe a guest</a>
                         
                            <h4>No guest subscribtions</h4>
                         </div>     
                         <?php else: ?>
                         <div class="card-body">
                         <a class="btn btn-success btn-sm mb-2" href="<?php echo e(route('subscriptions.showSubscribeGuest')); ?>">subscribe a guest</a>

                                <table id="myTable" class="table small-table-text">
                                    <thead>
                                    <tr style="white-space: nowrap; font-size: 14px;">

                                        <th>Guest Name</th>
                                        <th>Guest Phone</th>
                                        <th>Status</th>
                                        
                                        <th></th>
                                        

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $subscribtions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscribtion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="white-space: nowrap; font-size: 14px;">

                                            <td class=" text-black"><b><?php echo e($subscribtion->user->first_name); ?> <?php echo e($subscribtion->user->last_name); ?></b></td>
                                            <td>
                                            <?php echo e($subscribtion->user->phone); ?>


                                            </td>   

                                            <td>
                                                <span class="badge <?php echo e($subscribtion->is_online ? 'badge-green' : 'badge-red'); ?>">
                                                    <?php echo e($subscribtion->is_online ? 'ACTIVE' : 'ENDED'); ?>

                                                    </span>
                 
                                            </td>
                                            
                                         <td>
                                            <?php if($subscribtion->is_online): ?>
                                            <form method="post" action="<?php echo e(route('subscriptions.unsubscribe')); ?>">
                                                <?php echo csrf_field(); ?> 
                                                <?php echo method_field('PUT'); ?>
                                                <input type="hidden" name="userId" value="<?php echo e($subscribtion->user_id); ?>"/>
                                                <button type="submit" class="btn btn-danger btn-sm">unsubscribe</button>
                                            </form>
                                            <?php endif; ?>
                                         </td>
                                        

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        <?php endif; ?>

                       
                    </div>
                </div>

        
    </main>





<script>
    let table = new DataTable('#myTable', {
        ordering: false // Disable DataTables' default ordering
    });
</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/subscribtions/guestSubscribtions.blade.php ENDPATH**/ ?>