

<?php $__env->startSection('content'); ?>

<main>
    <!-- Main page content -->
    <div class="container mt-n5">

        <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
        <div class="card">
            <div class="card-header">Edit OnBoarding Slide</div>
            <div class="card-body">

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('onboardings.update', $onBoarding->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="row gx-3 mb-3">
                        <!-- Title -->
                        <div class="col-md-6">
                            <label class="small mb-1" for="title">Title</label>
                            <input type="text" name="title" id="title" class="form-control" value="<?php echo e($onBoarding->title); ?>" required />
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Subtitle -->
                        <div class="col-md-6">
                            <label class="small mb-1" for="subtitle">Subtitle</label>
                            <input type="text" name="subtitle" id="subtitle" class="form-control" value="<?php echo e($onBoarding->subtitle); ?>" required />
                            <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row gx-3 mb-3">
                        <!-- Image URL -->
                        <div class="col-md-6">
                            <label class="small mb-1" for="image_url">Image URL</label>
                            <input type="url" name="image_url" id="image_url" class="form-control" value="<?php echo e($onBoarding->image_url); ?>" required />
                            <?php $__errorArgs = ['image_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Text Button -->
                        <div class="col-md-6">
                            <label class="small mb-1" for="textbutton">Text Button</label>
                            <input type="text" name="textbutton" id="textbutton" class="form-control" value="<?php echo e($onBoarding->textbutton); ?>" required />
                            <?php $__errorArgs = ['textbutton'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row gx-3 mb-3">
                        <!-- Slide ID (Readonly) -->
                        <div class="col-md-6">
                            <label class="small mb-1" for="slide_id">Slide ID (Readonly)</label>
                            <input type="number" name="slide_id" id="slide_id" class="form-control" value="<?php echo e($onBoarding->slide_id); ?>" readonly />
                        </div>

                        <!-- Order (Readonly) -->
                        <div class="col-md-6">
                            <label class="small mb-1" for="order">Order (Readonly)</label>
                            <input type="number" name="order" id="order" class="form-control" value="<?php echo e($onBoarding->order); ?>" readonly />
                        </div>
                    </div>

                    <div class="row gx-3 mb-3" style="margin-top: 40px;">
                        <!-- Update Button -->
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-primary btn-sm">Update</button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/onBoardings/edit.blade.php ENDPATH**/ ?>