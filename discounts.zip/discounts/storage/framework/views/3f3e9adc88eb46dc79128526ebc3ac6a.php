

<?php $__env->startSection('content'); ?>


    <main>


        <!-- Main page content-->
        <div class="container mt-n5">


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">



           <div class="card">
                    <div class="card-header">Main Page Images </div>
                    <?php if(session('success')): ?>

                    <div class="alert alert-success m-3" role="alert"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php if($errors->has('fail')): ?>
                        <div class="alert alert-danger m-3">
                            <?php echo e($errors->first('fail')); ?>

                        </div>
                    <?php endif; ?>

                        <?php if($options->isEmpty()): ?>
                        <div class="card-body">
                        
                            No Images Options
                         </div>
                        <?php else: ?>
                        <div class="card-body">
                                <table id="myTable" class="table small-table-text">
                                    <thead>
                                    <tr style="white-space: nowrap; font-size: 14px;">

                                        <th>Key</th>
                                        <th>Image</th>
                                      
                                        <th>Actions</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="white-space: nowrap; font-size: 14px;">

                                            <td class=" text-black"><b><?php echo e($option->key); ?></b></td>
                                            <td> 
                                            <?php if(isset($option->img)): ?>
                                            <img src="<?php echo e(asset('optionImages/'.$option->img)); ?>" alt="Option Picture" width="100" height="100">
                                            <?php else: ?>
                                                No Image Yet 
                                            <?php endif; ?>   
                                        </td>
                                            
                                            <td>
                                            <a href="<?php echo e(route('options.editImageOption', $option->id )); ?>" class="btn btn-primary btn-xs">Edit</a>

                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
        
    </main>

<script>
    let table = new DataTable('#myTable');
</script>
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/options/showImages.blade.php ENDPATH**/ ?>