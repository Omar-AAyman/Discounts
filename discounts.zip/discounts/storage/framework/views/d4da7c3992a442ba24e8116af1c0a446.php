

<?php $__env->startSection('content'); ?>


    <main>


        <!-- Main page content-->
        <div class="container mt-n5">


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

                    <div class="card">
                    <div class="card-header">Sections List
                   
                    </div>
                        <?php if(session('success')): ?>

                        <div class="alert alert-success m-3" role="alert"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if($errors->has('fail')): ?>
                            <div class="alert alert-danger m-3">
                                <?php echo e($errors->first('fail')); ?>

                            </div>
                        <?php endif; ?>


                        <?php if($sections->isEmpty()): ?>
                        <div class="card-body">
                         
                            <h4>No sections</h4>
                         </div>     
                         <?php else: ?>
                         <div class="card-body">
                                <table id="myTable" class="table small-table-text">
                                    <thead>
                                    <tr style="white-space: nowrap; font-size: 14px;">

                                        <th>Name</th>
                                        <th>Type</th>
                                        <th>Belongs to package</th>
                                       
                                        
                                        <th>Is Online</th>
                                        <th>Actions</th>
                                        <th></th>
                                        

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="white-space: nowrap; font-size: 14px;">

                                            <td class=" text-black"><b><?php echo e($section->name); ?></b></td>
                                            <td><?php echo e($section->type); ?></td>
                                            <td><?php echo e($section->package->name); ?></td>
               

                                            <td>
                                                <span class="badge <?php echo e($section->is_online ? 'badge-green' : 'badge-red'); ?>">
                                                    <?php echo e($section->is_online ? 'Online' : 'Offline'); ?>

                                                    </span>
                 
                                            </td>
                                            
                                            <td>
                                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('sections.edit' , ['uuid'=>$section['uuid'] ])); ?>" >   
                                            Edit
                                              </a>
                                        

                                        
                                        
                                        </td>
                                        <td>
                                        <a class="btn btn-success btn-sm" href="<?php echo e(route('sections.showStores' , ['uuid'=>$section['uuid'] ])); ?>" >   
                                            Show stores points
                                              </a> 
                                        </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        <?php endif; ?>

                       
                    </div>
                </div>

        
    </main>





<script>
    let table = new DataTable('#myTable', {
        ordering: false // Disable DataTables' default ordering
    });
</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/sections/index.blade.php ENDPATH**/ ?>