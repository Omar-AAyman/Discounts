
<?php $__env->startSection('content'); ?>

<main>
        <!-- Main page content-->
        <div class="container mt-n5">

           


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

                    <div class="card">
                    <div class="card-header">List Of News</div>
                    <div class="card-body">

                        <?php if($news->isEmpty()): ?>
                            <p>No News.</p>
                        <?php else: ?>
                            <div class=" mt-3 table-container">
                            <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                            <?php endif; ?>
                            
                                <table id="myTable" class="table small-table-text">
                                    <thead>
                                    <tr style="white-space: nowrap; font-size: 14px;">
                                        
                                        <th>Title</th>
                                        <th>Description</th>
                                        <th>Picture</th>

                                        <th>Is Online</th>
                                       
                                        <th>Actions</th>
                                        



                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="white-space: nowrap; font-size: 14px;">

                                            <td><?php echo e($new->title); ?></td>

                                            <td>
                                              <?php if($new->description): ?>  
                                                <?php
                                                $value = $new->description;
                                                $first5Words = mb_strimwidth($value, 0, 50, '...');
                                                ?>

                                                <?php echo e($first5Words); ?>

                                               <?php else: ?> 
                                               No Description 
                                               <?php endif; ?> 
                                            </td>

                                            <td>
                                                    <?php if(isset($new->img)): ?>
                                                    <img src="<?php echo e(asset('newsImages/'.$new->img)); ?>" alt=" Picture" width="100" height="100">
                                                    <?php else: ?>
                                                    <img src="<?php echo e(asset('assets/img/noimg.jpg')); ?>" alt="Product Picture" width="100" height="100">
                                                    <?php endif; ?> 
                                            </td>
                                            

                                            <td>
                                                <span class="badge <?php echo e($new->is_online ? 'badge-green' : 'badge-red'); ?>">
                                                    <?php echo e($new->is_online ? 'Online' : 'Offline'); ?>

                                                    </span>
                 
                                            </td>
        
                                          
                                            
                                            <td>
                                                <a href="<?php echo e(route('news.edit',$new->uuid)); ?>" class="btn btn-primary btn-xs">Edit</a>

                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>



                            </div>
                        <?php endif; ?>
                            
                     
                    </div>
                </div>
        </div>

</main>
<script>
    let table = new DataTable('#myTable', {
        ordering: false // Disable DataTables' default ordering
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/news/index.blade.php ENDPATH**/ ?>