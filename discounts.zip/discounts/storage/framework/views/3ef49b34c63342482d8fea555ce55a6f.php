

<?php $__env->startSection('content'); ?>


    <main>


        <!-- Main page content-->
        <div class="container mt-n5">


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

                    <div class="card">
                    <div class="card-header">Packages List
                   
                    </div>
                        <?php if(session('success')): ?>

                        <div class="alert alert-success m-3" role="alert"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if($errors->has('fail')): ?>
                            <div class="alert alert-danger m-3">
                                <?php echo e($errors->first('fail')); ?>

                            </div>
                        <?php endif; ?>


                        <?php if($packages->isEmpty()): ?>
                        <div class="card-body">
                         
                            <h4>No packages</h4>
                         </div>     
                         <?php else: ?>
                         <div class="card-body">
                                <table id="myTable" class="table small-table-text">
                                    <thead>
                                    <tr style="white-space: nowrap; font-size: 14px;">

                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Is Online</th>
                                        <th>Actions</th>
                                        <th></th>
                                        

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="white-space: nowrap; font-size: 14px;">

                                            <td class=" text-black"><b><?php echo e($package->name); ?></b></td>
                                            <td>
                                                            <?php
                                                                $words = explode(' ', $package->description);
                                                                echo implode(' ', array_slice($words, 0, 5));
                                                                if (count($words) > 5) {
                                                                    echo ' ...';
                                                                }
                                                            ?>

                                            </td>   

                                            <td>
                                                <span class="badge <?php echo e($package->is_online ? 'badge-green' : 'badge-red'); ?>">
                                                    <?php echo e($package->is_online ? 'Online' : 'Offline'); ?>

                                                    </span>
                 
                                            </td>
                                            
                                            <td>
                                            <a class="btn btn-primary btn-sm" href="<?php echo e(route('packages.edit' , ['uuid'=>$package['uuid'] ])); ?>" >   
                                            Edit
                                              </a>
                                        

                                        
                                        
                                        </td>
                                        <td>
                                        <a class="btn btn-success btn-sm" href="<?php echo e(route('packages.showSections' , ['uuid'=>$package['uuid'] ])); ?>" >   
                                           Show sections 
                                              </a> 
                                        </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        <?php endif; ?>

                       
                    </div>
                </div>

        
    </main>





<script>
    let table = new DataTable('#myTable', {
        ordering: false // Disable DataTables' default ordering
    });
</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/packages/index.blade.php ENDPATH**/ ?>