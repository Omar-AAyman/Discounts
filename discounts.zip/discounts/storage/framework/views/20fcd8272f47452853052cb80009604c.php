

<?php $__env->startSection('content'); ?>


    <main>
   

        <!-- Main page content-->
        <div class="container mt-n5">


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
                    <div class="card">
                    <div class="card-header">Add a new seller</div>
                    <div class="card-body">


                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('delegates.addSeller')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>

                        <div class="row gx-3 mb-3">

                        <div class="col-md-6">
                        <label class="small mb-1" for="seller_name">Seller's Name <span style="color: red;">*</span> </label>
                        <input type="text" name="seller_name" id="seller_name" class="form-control" value="<?php echo e(old('seller_name')); ?>" required/>
                        <?php $__errorArgs = ['seller_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="col-md-6">
                        <label class="small mb-1" for="store_name">Store's Name <span style="color: red;">*</span> </label>
                        <input type="text" name="store_name" id="store_name" class="form-control" value="<?php echo e(old('store_name')); ?>" required/>
                        <?php $__errorArgs = ['store_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        </div>

                        <div class="row gx-3 mb-3">

                        <div class="col-md-6">
                            <label class="small mb-1" for="section_id">Section <span style="color: red;">*</span></label>
                            <select name="section_id" id="section_id" class="form-control form-control-solid" required>
                                        <option value="" >Select a section </option>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($section->id); ?>"><?php echo e($section->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                
                        </div>

                        <div class="col-md-6">
                        <label class="small mb-1" for="licensed_operator_number">Licensed operator number</label>
                        <input type="text" name="licensed_operator_number" id="licensed_operator_number" class="form-control" value="<?php echo e(old('licensed_operator_number')); ?>"/>
                     
                        </div>



                    </div>
                <div class="row gx-3 mb-3">
                <div class="col-md-6">
                        <label class="small mb-1" for="sector_representative">Sector representative <span style="color: red;">*</span></label>
                        <input type="text" name="sector_representative" id="sector_representative" class="form-control" value="<?php echo e(old('sector_representative')); ?>" required/>

                                
                </div>
                        <div class="col-md-6">
                        <label class="small mb-1" for="location">Location <span style="color: red;">*</span></label>
                        <input id="location"  name="location" class="form-control" value="<?php echo e(old('location')); ?>" required/>
                                   <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        </div>



            <div class="row gx-3 mb-3">
                <div class="col-md-6">
                        <label class="small mb-1" for="phone_number1">Phone number 1 <span style="color: red;">*</span></label>
                        <input type="text" name="phone_number1" id="phone_number1" class="form-control" value="<?php echo e(old('phone_number1')); ?>" required/>

                                
                </div>
                        <div class="col-md-6">
                        <label class="small mb-1" for="phone_number2">Phone number 2</label>
                        <input type="text" name="phone_number2" id="phone_number2" class="form-control" value="<?php echo e(old('phone_number2')); ?>" />
               
                        </div>
                        </div>




            <div class="row gx-3 mb-3">
                <div class="col-md-6">
                        <label class="small mb-1" for="phone_number1">Email <span style="color: red;">*</span></label>
                        <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                
                </div>

                <div class="col-md-6">
                        <label class="small mb-1" for="working_hours">Working hours <span style="color: red;">*</span></label>
                        <input type="text" name="working_hours" id="working_hours" class="form-control" value="<?php echo e(old('working_hours')); ?>" required/>

                                
                </div>
            </div>



          <div class="row gx-3 mb-3">
                <div class="col-md-6">
                        <label class="small mb-1" for="working_days">Working days <span style="color: red;">*</span></label>
                        <input type="text" name="working_days" id="working_days" class="form-control" value="<?php echo e(old('working_days')); ?>" required/>

                                
                </div>

                <div class="col-md-6">
                        <label class="small mb-1" for="facebook">Facebook</label>
                        <input type="text" name="facebook" id="facebook" class="form-control" value="<?php echo e(old('facebook')); ?>" />

                                
                </div>
          </div>


          <div class="row gx-3 mb-3">
                <div class="col-md-6">
                        <label class="small mb-1" for="instagram">Instagram</label>
                        <input type="text" name="instagram" id="instagram" class="form-control" value="<?php echo e(old('instagram')); ?>"/>

                                
                </div>

                <div class="col-md-6" style="margin-top: 30.5px;">
                        <label class="btn btn-primary btn-sm"  for="contract_img">Contract Image</label>
                        <input style="display: none;" type="file" name="contract_img" id="contract_img" />
                        <span id="file-name" style="margin-left: 10px;"></span>

                                
                </div>
          </div>

          <div class="row gx-3 mb-3">

            <div class="col-md-6">
                            <label class="btn btn-primary btn-sm" for="store_img">Sector/Store Image</label>
                            <input style="display: none;" type="file" name="store_img" id="store_img" />
                            <span id="store-file-name" style="margin-left: 10px;"></span>

                                    
                    </div>

 
 
                        <div class="col-md-6">
                        <button type="submit" class="btn btn-primary btn-sm">Send</button>
                    </div></div>
                    </form>

            </div>
        </div>
        </div>
    </main>
    <script>
    // For Contract Image
    document.getElementById('contract_img').addEventListener('change', function() {
        var fileName = this.files[0].name;
        document.getElementById('file-name').textContent = fileName;
    });

    // For Store Image
    document.getElementById('store_img').addEventListener('change', function() {
        var fileName = this.files[0].name;
        document.getElementById('store-file-name').textContent = fileName;
    });
</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout-delegate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/create-seller.blade.php ENDPATH**/ ?>