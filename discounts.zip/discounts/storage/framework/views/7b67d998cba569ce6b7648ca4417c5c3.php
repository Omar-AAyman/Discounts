

<?php $__env->startSection('content'); ?>


    <main>


        <!-- Main page content-->
        <div class="container mt-n5">


                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

                    <div class="card">
                    <div class="card-header">Pending Adding Sellers Requests
                   
                    </div>
                        <?php if(session('success')): ?>

                        <div class="alert alert-success m-3" role="alert"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if($errors->has('fail')): ?>
                            <div class="alert alert-danger m-3">
                                <?php echo e($errors->first('fail')); ?>

                            </div>
                        <?php endif; ?>


                        <?php if($stores->isEmpty()): ?>
                        <div class="card-body">
                         
                            <h4>No requests yet</h4>
                         </div>     
                         <?php else: ?>
                         <div class="card-body">
                                <table id="myTable" class="table small-table-text">
                                    <thead>
                                    <tr style="white-space: nowrap; font-size: 14px;">

                                        <th>Delegate Name</th>
                                        <th>Seller Name</th>
                                        <th>Store</th>
                                        <th>Section</th>
                                        <th></th>
                                        
                                       
                                        

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                         $delegate = DB::table('users')->where('id',$store->delegate_id)->first();
                                          ?>
                                        <tr style="white-space: nowrap; font-size: 14px;">

                                            <td class=" text-black"><b><?php echo e($delegate->first_name); ?> <?php echo e($delegate->last_name); ?></b></td>
                                            <td class=" text-black"><b><?php echo e($store->seller_name); ?></b></td>
                                            <td><?php echo e($store->name); ?></td>
                                            <td><?php echo e($store->section->name); ?></td>
               

                                            
                                            <td>
                                            <form method="get" action="<?php echo e(route('stores.approveSeller')); ?>">
                                                <?php echo csrf_field(); ?> 
                                                <input type="hidden" name="store_id" value="<?php echo e($store->id); ?>"/>
                                                <button type="submit" class="btn btn-success btn-sm">Approve</button>
                                            </form>
                                        

                                        
                                        
                                        </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        <?php endif; ?>

                       
                    </div>
                </div>

        
    </main>





<script>
    let table = new DataTable('#myTable', {
        ordering: false // Disable DataTables' default ordering
    });
</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/stores/show-sellers-requests.blade.php ENDPATH**/ ?>