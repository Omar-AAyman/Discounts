

<?php $__env->startSection('content'); ?>


    <main>


        <!-- Main page content-->
        <div class="container mt-n5">




                    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

                    <div class="card">
                    <div class="card-header">Tickets List List</div>

                    <?php if(session('success')): ?>

                        <div class="alert alert-success m-3" role="alert"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <?php if($errors->has('fail')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e($errors->first('fail')); ?>

                                </div>
                            <?php endif; ?>

                        <?php if($tickets->isEmpty()): ?>
                        <div class="card-body">
                         <form method="GET" action="<?php echo e(route('tickets.create')); ?>">
                             <div class="col-md-6">
                             <label class="small mb-1 mr-5" for="max_products">No Tickets</label>
                             <button type="submit" class="btn btn-primary btn-xs">Add Ticket</button>
                             </div>
                         </form>
                         </div>
                        <?php else: ?>
                        <div class="card-body">
                        <br>
                        <br>
                            <table id="myTable" class="table small-table-text">
                                    <thead>
                                    <tr style="white-space: nowrap; font-size: 14px;">
                                    <th>Ticket Title</th>
                                    <th>Ticket Body</th>
                                    <th>Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr style="white-space: nowrap; font-size: 14px;">

                                    <td class=" text-black"><b><?php echo e($ticket->title); ?></b></td>
                                    <td>
                                            <?php
                                                $words = explode(' ', $ticket->body);
                                                $body = implode(' ', array_slice($words, 0, 9)).'...';
                                            ?>
                                                    <?php echo e($body); ?>

                            
                            </td>
                                    <td>
                                    <a href="<?php echo e(route('tickets.show',['id'=>$ticket['id']])); ?>"
                                    class="btn btn-primary btn-xs">
                                    Show Replies  
                                   
                                    </a>
                                    </td>
                                    </tr>


                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                            <?php endif; ?>

                       
                    </div>
        </div>
    </main>

<script>
    let table = new DataTable('#myTable', {
        ordering: false // Disable DataTables' default ordering
    });
</script>  
<?php $__env->stopSection(); ?>        
                        








<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\discounts\resources\views/tickets/index.blade.php ENDPATH**/ ?>