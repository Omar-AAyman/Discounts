<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;


class UserApi extends Controller
{
    public function profile(Request $request){
        if(!PersonalAccessToken::findToken($request->bearerToken())->isExpired()){
       
        $lastSubscription = $request->user()->subscriptions()->where('is_online',1)->first();

            return response(['user'=>$request->user()
        ,'subscription package'=>$lastSubscription->package->name]);
       
        }
        else{
            return response(['message'=>'tolen is expired']);
        }
    }
}
